/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hospitalapplication.za.ac.tut.backend;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author SAMASSANGO
 */
public class FileUpdate {

    public FileUpdate() {
    }
    public void add(String strFile,String name,String surname,String idNo)throws IOException
    {
        String strInfo=null;
        String info=name+"#"+surname+"#"+idNo;
        File file= new File(strFile);
        BufferedWriter buf=new BufferedWriter(new FileWriter(file,true));
        buf.write(info);
        buf.newLine();
        buf.close();
    }
    public boolean delete(String strfile,String idNo) throws IOException
    {
        boolean isDeleted=false;
        ArrayList<String> array = getList(strfile);
        for(int x=0;x<array.size();x++)
        {
            String info=array.get(x);
            String[] strIfo=info.split("#");
            if(strIfo[0].equals(idNo))
            {
              array.remove(x);
              isDeleted=true;
            }
        }
       
        return isDeleted;
        
    }
    //adding info to the arrayList
    public ArrayList<String> getList(String strFile)throws IOException
    {      
        File file=new File(strFile); 
        ArrayList<String> dataArray=new ArrayList<String>();
         BufferedReader buff=new BufferedReader(new FileReader(file));
        String strInfo="";
         while((strInfo=buff.readLine())!=null)
         {
            dataArray.add(strInfo);
         }
         buff.close();
       return dataArray;
    }
    public Medication getMedication(String strFile,String medID)throws IOException
    {
       ArrayList<String> dataArray = getList(strFile);
       Medication medicine=null;
       for(int x=0;x<dataArray.size();x++)
       {
           String data=dataArray.get(x);
           String[] strInfo=data.split("#");
           if(medID.equals(strInfo[0]))
           {
               medicine=new Medication(strInfo[1], strInfo[0], strInfo[2]);
           }
       }
       return medicine;
    }
    public boolean update(String strFile, ArrayList<String> data,String idNo,String name,String surname)throws IOException
    {
        boolean isUpdated=false;
        File file=new File(strFile); 
        int index=-1;
        BufferedReader br=new BufferedReader(new FileReader(file));
	String record ="";
	
	while((record = br.readLine()) != null){
	   data.add(record);
	}
	br.close();
	
	for(int x=0;x < data.size();x++)
	{
	    String currRecord=data.get(x);
		String[] strInfo=currRecord.split("#");
		for(int y=0;y<strInfo.length;y++)
		{
		   if(idNo.equals(strInfo[0]))
		   {
		      index=x;
			  break;
		   }
		}
	}
	if(index!=-1){
	isUpdated=true;
	String newData=idNo+"#"+name+"#"+surname;
	data.set(index,newData);
	save(file,data);
	
	}
	
        /*
       String newData=idNo+"#"+name+"#"+surname;
       int position=-1;
       
       for(int x=0;x<data.size();x++)
       {
            String info=data.get(x);
            String[] infoArray=info.split("#");
            if(idNo.equals(infoArray[0]))
            {
                position=x;
            }
       }
    
       if(position!=-1){
            data.set(position, newData);
            isUpdated=true;
       }
       //save new data to a file
       BufferedWriter buf=new BufferedWriter(new FileWriter(file,false));
        for(int x=0;x<data.size();x++)
        {
             buf.write(data.get(x));
             buf.newLine();
        }*/
       
       return isUpdated;
    }
   
    public Person[] getAllPatients(String strfile) throws IOException
    {
        String strInfo=null;
        Person[] person=null;
        File file=new File(strfile); 
        BufferedReader buff=new BufferedReader(new FileReader(file));
        int noLine = noLines(file);
        person=new Person[noLine];
        strInfo=buff.readLine();
        for(int x=0;x < person.length;x++)
        {
            String[] patient=strInfo.split("#");
            person[x]=new Pharmacist(patient[0], patient[1], patient[2]); 
            
             strInfo=buff.readLine();
        }
        buff.close();
        return person;
    }
    public Medication[] getPrescription(String strfile) throws IOException
    {
        String strInfo=null;
        Medication[] medicine=null;
        File file=new File(strfile); 
        BufferedReader buff=new BufferedReader(new FileReader(file));
        int noLine = noLines(file);
        medicine=new Medication[noLine];
        strInfo=buff.readLine();
        for(int x=0;x < medicine.length;x++)
        {
            String[] med=strInfo.split("#");
            medicine[x]=new Medication(med[0], med[1],med[2],med[3],med[4]); 
            
             strInfo=buff.readLine();
        }
        buff.close();
        return medicine;
    }
     public String getPetiant(String strfile,String idNo) throws IOException
    {
        String strInfo=null;
    
        File file=new File(strfile); 
        BufferedReader buff=new BufferedReader(new FileReader(file));
        int noLine = noLines(file);
        String strPerson="";
        strInfo=buff.readLine();
        while(strInfo!=null)
        {
            String[] patient=strInfo.split("#");
             if(idNo.equalsIgnoreCase(patient[2]))
             {
                 strPerson=strInfo;
             }
             strInfo=buff.readLine();
        }
        buff.close();
        return strPerson;
    }
     
    public int noLines(File file) throws IOException
    {
        String strInfo=" ";
        int noOfLines=0;
        BufferedReader buff=new BufferedReader(new FileReader(file));
        strInfo=buff.readLine();
        while(strInfo!= null)
        {
            noOfLines+=1;
             strInfo=buff.readLine();
        }
        buff.close();
        return noOfLines;
    }
  
    public void addMedicine(String strFile,String refID,String medication_name, String medication_type)throws IOException
    {
        String strInfo=null;
        String info=refID+"#"+medication_type+"#"+medication_name;
        File file= new File(strFile);
        BufferedWriter buf=new BufferedWriter(new FileWriter(file,true));
        buf.write(info);
        buf.newLine();
        buf.close();
    }
    public void addPrescription(String strFile,String name,String surname,String idNo,String medication_name, String medication_type)throws IOException
    {
        String strInfo=null;
        String info=name+"#"+surname+"#"+idNo+"#"+medication_type+"#"+medication_name;
        File file= new File(strFile);
        BufferedWriter buf=new BufferedWriter(new FileWriter(file,true));
        buf.write(info);
        buf.newLine();
        buf.close();
       
    }
    @Override
    public String toString() {
        return "FileUpdate{" + '}';
    }

    private void save(File file, ArrayList<String> data)throws IOException
    {
        BufferedWriter bw=new BufferedWriter(new FileWriter(file,false));
        for(int y=0;y<data.size();y++){
            bw.write(data.get(y));
            bw.newLine();
        }
        bw.close();
    }
     
}
