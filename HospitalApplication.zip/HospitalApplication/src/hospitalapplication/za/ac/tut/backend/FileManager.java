/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hospitalapplication.za.ac.tut.backend;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author SAMASSANGO
 */
public class FileManager {
    public void writeObject(Person objPerson)throws IOException
    {
        String name=objPerson.getName();
        String surname=objPerson.getSurname();
        String idNo=objPerson.getIdNo();
        String info=name+"#"+surname+"#"+idNo;
        File file= new File("information.txt");
        BufferedWriter buf=new BufferedWriter(new FileWriter(file,true));
        buf.write(info);
        buf.newLine();
    }
    public Person[] readObject()throws IOException
    {
       String strInfo=null;
        Person[] person=null;
        File file=new File("information.txt"); 
        BufferedReader buff=new BufferedReader(new FileReader(file));
        int noLine = noLines(file);
        person=new Person[noLine];
        strInfo=buff.readLine();
        for(int x=0;x < person.length;x++)
        {
            String[] patient=strInfo.split("#");
            person[x]=new Pharmacist(patient[0], patient[1], patient[2]); 
            
             strInfo=buff.readLine();
        }
        return person;
    }
    public int noLines(File file) throws IOException
    {
        String strInfo=" ";
        int noOfLines=0;
        BufferedReader buff=new BufferedReader(new FileReader(file));
        strInfo=buff.readLine();
        while(strInfo!= null)
        {
            noOfLines+=1;
             strInfo=buff.readLine();
        }
        return noOfLines;
    }
  
}
