/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hospitalapplication.za.ac.tut.backend;

/**
 *
 * @author SAMASSANGO
 */
public abstract class Person
{
    private String name;
    private String surname;
    private String idNo;

    public Person(String name, String surname, String idNo) {
        this.name = name;
        this.surname = surname;
        this.idNo = idNo;
     
    }
    /**
     * Get the value of idNo
     *
     * @return the value of idNo
     */
    public String getIdNo() {
        return idNo;
    }

    /**
     * Set the value of idNo
     *
     * @param idNo new value of idNo
     */
    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    /**
     * Get the value of surname
     *
     * @return the value of surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Set the value of surname
     *
     * @param surname new value of surname
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Get the value of name
     *
     * @return the value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the value of name
     *
     * @param name new value of name
     */
    public void setName(String name) {
        this.name = name;
    }
 
}
