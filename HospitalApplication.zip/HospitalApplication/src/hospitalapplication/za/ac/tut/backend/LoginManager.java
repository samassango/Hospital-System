/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hospitalapplication.za.ac.tut.backend;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author SAMASSANGO
 */
public class LoginManager {
    public void addUser(String password,String username,String role)throws IOException
    {
        String strInfo=null;
        String info=password+"#"+username+"#"+role;
        File file= new File("./users.txt");
        BufferedWriter buf=new BufferedWriter(new FileWriter(file,true));
        buf.write(info);
        buf.newLine();
        buf.close();
    }
    public boolean getUser(String password,String username,String role)throws IOException
    {
       String strInfo=null;
    
        File file=new File("./users.txt"); 
        BufferedReader buff=new BufferedReader(new FileReader(file));
        boolean isValid=false;
        strInfo=buff.readLine();
        while(strInfo!=null)
        {
            String[] users=strInfo.split("#");
            System.out.println(users.length);
             if(role.equalsIgnoreCase(users[2]))
             {
                 if(password.equals(users[0])&& username.equals(users[1]))
                 {
                    isValid=true;
                 }
                
             }
             strInfo=buff.readLine();
        }
        buff.close();
        return isValid;
    }
}
