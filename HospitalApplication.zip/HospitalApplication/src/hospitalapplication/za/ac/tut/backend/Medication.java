/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hospitalapplication.za.ac.tut.backend;

/**
 *
 * @author SAMASSANGO
 */
public class Medication 
{
    private String name;
    private String surname;
    private String medication_name;
     private String petient_id;
    private String medication_type;

    public Medication(String medication_name, String petient_id, String medication_type) {
        this.medication_name = medication_name;
        this.petient_id = petient_id;
        this.medication_type = medication_type;
    }

    public Medication(String name,String surname,String petient_id,String medication_name, String medication_type) {
         this.name = name;
         this.surname = surname;
         this.petient_id = petient_id;
        this.medication_name = medication_name;
        this.medication_type = medication_type;
    }
 

    /**
     * Get the value of surname
     *
     * @return the value of surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Set the value of surname
     *
     * @param surname new value of surname
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Get the value of name
     *
     * @return the value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the value of name
     *
     * @param name new value of name
     */
    public void setName(String name) {
        this.name = name;
    }


    /**
     * Get the value of petient_id
     *
     * @return the value of petient_id
     */
    public String getPetient_id() {
        return petient_id;
    }

    /**
     * Set the value of petient_id
     *
     * @param petient_id new value of petient_id
     */
    public void setPetient_id(String petient_id) {
        this.petient_id = petient_id;
    }

    /**
     * Get the value of medication_type
     *
     * @return the value of medication_type
     */
    public String getMedication_type() {
        return medication_type;
    }

    /**
     * Set the value of medication_type
     *
     * @param medication_type new value of medication_type
     */
    public void setMedication_type(String medication_type) {
        this.medication_type = medication_type;
    }

    /**
     * Get the value of medication_name
     *
     * @return the value of medication_name
     */
    public String getMedication_name() {
        return medication_name;
    }

    /**
     * Set the value of medication_name
     *
     * @param medication_name new value of medication_name
     */
    public void setMedication_name(String medication_name) {
        this.medication_name = medication_name;
    }

}
